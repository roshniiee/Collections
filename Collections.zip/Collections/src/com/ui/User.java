package com.ui;

import java.util.Random;
import java.util.Scanner;

import com.bean.Customer;
import com.service.BankService;

public class User {
	Random random = new Random();
	BankService bankService = new BankService();
	Scanner scan = new Scanner(System.in);

	public void createAccount() {
		System.out.println("Customer Application");
		System.out.println("---------------------------------------");
		System.out.println("Enter Your Full Name:");
		String name = scan.next();
		System.out.println("Enter Your Mobile Number:");
		long phone = scan.nextLong();
		System.out.println("Enter Your 12 Digit Aadhar Number:");
		long aadhar = scan.nextLong();
		long accNo = random.nextInt(1000000000);
		float balance = 500;
		System.out.println("Your Initial Balance: " + balance);
		System.out.println("Your Account Number : " + accNo);
		System.out.println("Your Account is created Successfully!!");
		Customer customer = new Customer(name, phone, accNo, balance, aadhar);
		bankService.createAccount(customer);

	}

	public void showBalance() {
		System.out.println("Enter Your Account Number:");
		long accNo = scan.nextLong();
		Customer customer = bankService.showBalance(accNo);
		System.out.println("Your Balance is:" + customer.getBalance());

	}

	public void deposit() {
		System.out.println("Enter Account Number:");
		long accno = scan.nextLong();
		System.out.println("enter Amount to be Deposited:");
		int amount = scan.nextInt();
		Customer customer=bankService.deposit(accno, amount);
		System.out.println("your current balance is"+customer.getBalance());

	}

	public void withdraw() {
		System.out.println("Enter Account Number:");
		long accno = scan.nextLong();
		System.out.println("enter Amount to be Withdrawn:");
		int amount = scan.nextInt();
		Customer customer=bankService.withdraw(accno, amount);
		System.out.println("your current balance is"+customer.getBalance());

	}

	public void fundTransfer() {
		System.out.println("Enter your AccountNumber:");
		long sourceAccNo = scan.nextLong();
		System.out.println("enter the AccountNumber to be transfered:");
		long destinationAccNo = scan.nextLong();
		System.out.println("enter Amount to be transfered:");
		int tfamount = scan.nextInt();
		Customer source=bankService.fundTransfer(sourceAccNo,destinationAccNo,tfamount);
		System.out.println("Transfered successfully!!"+"\n"+"Source Balance :"+source.getBalance());

	}

	public void printTransactions() {

	}

}
