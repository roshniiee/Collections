/*package com.DAO;

import java.util.HashMap;

import com.bean.Customer;

public class BankDAO {
	HashMap<Long, Customer> hashMap = new HashMap<Long, Customer>();

	public void createAccount(Customer customer) {
		hashMap.put(customer.getAccountNo(), customer);

	}

	public Customer showBalance(long accNo) {
		return hashMap.get(accNo);

	}

	public Customer deposit(long accno, int amount) {
		Customer cust = hashMap.get(accno);
		float initialBalance = cust.getBalance();
		float finalBalance = initialBalance + amount;
		cust.setBalance(finalBalance);
		return cust;

	}

	public Customer withdraw(long accno, int amount) {
		Customer cust = hashMap.get(accno);
		float initialBalance = cust.getBalance();
		float finalBalance = initialBalance - amount;
		cust.setBalance(finalBalance);
		return cust;

	}

	public Customer fundTransfer(long sourceAccNo, long destinationAccNo, int tfamount) {
		Customer sourceCust = hashMap.get(sourceAccNo);
		float SourceinitialBalance = sourceCust.getBalance();
		Customer DestiCust = hashMap.get(destinationAccNo);
		float DestinationinitialBalance = DestiCust.getBalance();
		float sourceFinalbal = SourceinitialBalance - tfamount;
		float destinationFinalbal = DestinationinitialBalance + tfamount;
		sourceCust.setBalance(sourceFinalbal);
		DestiCust.setBalance(destinationFinalbal);
		hashMap.put(destinationAccNo, DestiCust);
		hashMap.put(sourceAccNo, sourceCust);
		return sourceCust;

	}

}
*/